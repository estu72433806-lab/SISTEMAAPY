"""
Módulo de Conexión a MySQL (Nube / Servidor Remoto).
Usa mysql-connector-python, valida la conexión, aplica un tiempo límite (timeout)
para no congelar la interfaz y cierra los recursos de forma segura.
"""
import mysql.connector
from database.mysql_config import obtener_configuracion_mysql, tiene_credenciales_mysql


def get_mysql_connection(timeout: int = None, config_override: dict = None):
    """
    Retorna (conexion, None) si conecta, o (None, mensaje_de_error) si no es posible
    conectar o el servidor no responde dentro del timeout.
    sslmode 'disable' desactiva SSL; cualquier otro valor lo usa cuando el servidor lo soporta.
    """
    config = config_override if config_override else obtener_configuracion_mysql()

    host = str(config.get("mysql_host", "")).strip()
    port = int(config.get("mysql_port", 3306))
    database = str(config.get("mysql_database", "")).strip()
    user = str(config.get("mysql_user", "")).strip()
    password = config.get("mysql_password", "")
    sslmode = str(config.get("mysql_sslmode", "prefer")).strip()
    timeout_seg = timeout if timeout is not None else config.get("timeout_segundos", 4)

    if not host or not database or not user:
        return None, "Faltan datos de configuración de MySQL (Servidor, Base de Datos o Usuario)."

    try:
        conn = mysql.connector.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password,
            ssl_disabled=(sslmode == "disable"),
            connection_timeout=timeout_seg,
        )
        return conn, None
    except mysql.connector.Error as e:
        msg = str(e).strip()
        if "timed out" in msg.lower() or "timeout" in msg.lower():
            return None, f"Tiempo de espera agotado al conectar a MySQL ({timeout_seg}s). Servidor inaccesible."
        return None, f"Error de conexión a MySQL: {msg}"
    except Exception as e:
        return None, f"Error inesperado al conectar a MySQL: {str(e)}"


def probar_conexion_mysql(config_override: dict = None) -> tuple[bool, str]:
    """
    Prueba rápida de conectividad con MySQL.
    Retorna (True, mensaje) o (False, mensaje de error).
    """
    conn, err = get_mysql_connection(timeout=3, config_override=config_override)
    if not conn:
        return False, err

    try:
        cur = conn.cursor()
        cur.execute("SELECT VERSION();")
        ver = cur.fetchone()
        version_str = f"MySQL {ver[0]}" if ver else "MySQL"
        cur.close()
        conn.close()
        return True, f"Conexión exitosa a la nube: {version_str}"
    except Exception as e:
        try:
            conn.close()
        except Exception:
            pass
        return False, f"Fallo en consulta de prueba: {str(e)}"
