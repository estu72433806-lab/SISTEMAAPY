"""
Módulo de Configuración Segura para MySQL (Nube / Servidor Remoto).
Maneja credenciales mediante variables de entorno o archivo 'config_db.json' (ignorado por Git).
No expone contraseñas en código fuente.
"""
import os
import json
from urllib.parse import urlparse, parse_qs, unquote

CONFIG_FILENAME = "config_db.json"
EXAMPLE_FILENAME = "config_db.example.json"

def get_base_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_config_path():
    return os.path.join(get_base_dir(), CONFIG_FILENAME)

def get_example_path():
    return os.path.join(get_base_dir(), EXAMPLE_FILENAME)

def crear_archivo_ejemplo_si_no_existe():
    """Crea un archivo plantilla config_db.example.json para guiar al usuario."""
    path = get_example_path()
    if not os.path.exists(path):
        ejemplo = {
            "mysql_host": "localhost",
            "mysql_port": 3306,
            "mysql_database": "techstore",
            "mysql_user": "techstore",
            "mysql_password": "TU_PASSWORD_AQUI",
            "mysql_sslmode": "prefer",
            "auto_sync": True,
            "timeout_segundos": 4
        }
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(ejemplo, f, indent=4)
        except Exception:
            pass

def obtener_configuracion_mysql() -> dict:
    """
    Obtiene los parámetros de conexión a MySQL priorizando:
    1. Variables de entorno (MYSQL_HOST, MYSQL_PORT, MYSQL_DATABASE, MYSQL_USER, MYSQL_PASSWORD, MYSQL_SSLMODE)
    2. Archivo local seguro 'config_db.json'
    3. Valores por defecto (desconectado)
    """
    crear_archivo_ejemplo_si_no_existe()

    config = {
        "mysql_host": os.environ.get("MYSQL_HOST", ""),
        "mysql_port": int(os.environ.get("MYSQL_PORT", 3306)),
        "mysql_database": os.environ.get("MYSQL_DATABASE", ""),
        "mysql_user": os.environ.get("MYSQL_USER", ""),
        "mysql_password": os.environ.get("MYSQL_PASSWORD", ""),
        "mysql_sslmode": os.environ.get("MYSQL_SSLMODE", "prefer"),
        "timeout_segundos": int(os.environ.get("MYSQL_TIMEOUT", 4)),
        "auto_sync": os.environ.get("MYSQL_AUTO_SYNC", "true").lower() in ("true", "1", "yes")
    }

    config_file = get_config_path()
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                file_data = json.load(f)
                for k, v in file_data.items():
                    # Solo sobreescribe si la variable de entorno no estaba fijada
                    if not config.get(k):
                        config[k] = v
        except Exception as e:
            print(f"Aviso: no se pudo leer {CONFIG_FILENAME}: {e}")

    return config

def guardar_configuracion_mysql(nueva_config: dict) -> tuple[bool, str]:
    """Guarda la configuración en config_db.json de forma segura."""
    config_file = get_config_path()
    try:
        # Asegurarse de tipos correctos
        datos = {
            "mysql_host": str(nueva_config.get("mysql_host", "")).strip(),
            "mysql_port": int(nueva_config.get("mysql_port", 3306)),
            "mysql_database": str(nueva_config.get("mysql_database", "")).strip(),
            "mysql_user": str(nueva_config.get("mysql_user", "")).strip(),
            "mysql_password": str(nueva_config.get("mysql_password", "")),
            "mysql_sslmode": str(nueva_config.get("mysql_sslmode", "prefer")).strip(),
            "timeout_segundos": int(nueva_config.get("timeout_segundos", 4)),
            "auto_sync": bool(nueva_config.get("auto_sync", True))
        }
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=4)
        return True, "Configuración guardada correctamente."
    except Exception as e:
        return False, f"Error al guardar configuración: {str(e)}"

def tiene_credenciales_mysql() -> bool:
    """Verifica si al menos están especificados el host y la base de datos."""
    c = obtener_configuracion_mysql()
    return bool(c.get("mysql_host") and c.get("mysql_database") and c.get("mysql_user"))

def parse_connection_string(conn_string: str) -> tuple[dict, str]:
    """
    Parsea una URL de conexión de MySQL (ej: mysql://user:pass@host:3306/dbname?sslmode=require)
    comúnmente provista por servicios como tu proveedor cloud, tu proveedor cloud, tu proveedor cloud, AWS, etc.
    Retorna (dict_datos, None) o (None, mensaje_error).
    """
    if not conn_string or not isinstance(conn_string, str):
        return None, "La cadena de conexión está vacía."

    s = conn_string.strip()
    # Quitar comillas envolventes si el usuario copió la URL con ellas
    s = s.strip("'\"`")

    if not (s.startswith("mysql://")):
        return None, "La URL debe comenzar con 'mysql://'."

    try:
        parsed = urlparse(s)
        host = parsed.hostname or ""
        port = parsed.port or 3306
        user = unquote(parsed.username or "")
        password = unquote(parsed.password or "")

        # Eliminar barra inicial del path para obtener el nombre de la BD
        database = parsed.path.lstrip("/") if parsed.path else ""

        query_params = parse_qs(parsed.query)
        sslmode = query_params.get("sslmode", ["require"])[0]

        if not host:
            return None, "No se pudo identificar el Host / Servidor en la URL ingresada."
        if not database:
            return None, "No se pudo identificar el nombre de la Base de Datos en la URL."
        if not user:
            return None, "No se pudo identificar el Usuario en la URL."

        datos = {
            "mysql_host": host,
            "mysql_port": port,
            "mysql_database": database,
            "mysql_user": user,
            "mysql_password": password,
            "mysql_sslmode": sslmode,
            "timeout_segundos": 4,
            "auto_sync": True
        }
        return datos, None
    except Exception as e:
        return None, f"Error al procesar la cadena de conexión: {str(e)}"

